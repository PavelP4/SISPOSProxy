How to build, install and test UDFMessenger:

1. Build "UDFMessenger.dll" library and "UDFTestRecipient.exe" application with "Release|x64" configuration.

2. Copy both binary files to SIS POS machine.

3. Stop "MySQL57" service (it is only necessary if you replace old "UDFMessenger.dll" library).

4. Copy "UDFMessenger.dll" library into "C:\Program Files\MySQL\MySQL Server 5.7\lib\plugin" folder.

5. Start "MySQL57" service.

6. Create UDFs in "pos" DB:

    CREATE FUNCTION TAGMSG RETURNS INTEGER SONAME 'UDFMessenger.dll';
    CREATE FUNCTION SECMSG RETURNS INTEGER SONAME 'UDFMessenger.dll';
    CREATE FUNCTION POSMSG RETURNS INTEGER SONAME 'UDFMessenger.dll';

7. Run "UDFTestRecipient.exe" application (it will wait for incoming messages).

8. Run test SQL queries on "MySQL57" server:

    SELECT TAGMSG(1,2);
    SELECT SECMSG(3,4);
    SELECT POSMSG(5,6);

9. Check output in console window of "UDFTestRecipient.exe" application:

    TAG 001 002
    SEC 003 004
    POS 005 006
